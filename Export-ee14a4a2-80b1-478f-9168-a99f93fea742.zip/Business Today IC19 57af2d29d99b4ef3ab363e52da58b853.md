# Business Today IC19

Created: August 25, 2019 9:30 PM
Updated: December 18, 2020 12:38 AM

[2019_International_Conference_Application_-_Business_Today_-_Career_Page.pdf](Business%20Today%20IC19%2057af2d29d99b4ef3ab363e52da58b853/2019_International_Conference_Application_-_Business_Today_-_Career_Page.pdf)

Resume for the same :

[BTCon_Resume_Mritunjay.pdf](Business%20Today%20IC19%2057af2d29d99b4ef3ab363e52da58b853/BTCon_Resume_Mritunjay.pdf)